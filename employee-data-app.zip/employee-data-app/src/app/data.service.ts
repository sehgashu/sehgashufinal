// data.service.ts

import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class DataService {
  private employeeData: any;

  setData(data: any) {
    this.employeeData = data;
    console.log('Data Set in DataService:', data);
  }

  getData() {
    console.log('Data Retrieved from DataService:', this.employeeData);
    return this.employeeData;
  }
}