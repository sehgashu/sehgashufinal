import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OutputResultComponent } from './output-result.component';

describe('OutputResultComponent', () => {
  let component: OutputResultComponent;
  let fixture: ComponentFixture<OutputResultComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [OutputResultComponent]
    });
    fixture = TestBed.createComponent(OutputResultComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
