// output-result.component.ts

import { Component } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-output-result',
  templateUrl: './output-result.component.html',
  styleUrls: ['./output-result.component.css'],
})
export class OutputResultComponent {
  constructor(private dataService: DataService) {}

  get employee() {
    return this.dataService.getData();
  }
}