// input-form.component.ts

import { Component } from '@angular/core';
import { DataService } from '../data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-input-form',
  templateUrl: './input-form.component.html',
  styleUrls: ['./input-form.component.css'],
})
export class InputFormComponent {
  employee = {
    name: '',
    salary: null,
    employmentTerm: 'permanent',
    certified: false,
  };

  constructor(private dataService: DataService, private router: Router) {}

  onSubmit() {
    this.dataService.setData(this.employee);
    console.log('Submit Clicked. Data Submitted:', this.employee);
    this.router.navigate(['/output']);
  }
}